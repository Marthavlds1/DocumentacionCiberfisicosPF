# Dashboard industrial externo

Este dashboard NO modifica la lógica de tu rutina. La ejecuta como subproceso y observa los `print()` que tu código ya genera, especialmente:

- `[ESTADO] Etapa actual -> ...`
- `[PC] Error en pedido: ...`
- `[PC] Error en loop principal: ...`
- `[PLC] Motor iniciado/detenido`
- `[MASCARAS] S1=... | S2=... | S3=...`

## Instalación

1. Coloca tu archivo original junto a `dashboard_server.py`.
2. Renombra tu archivo original como:

```bash
rutina_maestra.py
```

O deja su nombre original y ejecuta:

```bash
ROUTINE_FILE="mi_codigo_original.py" python dashboard_server.py
```

En Windows PowerShell:

```powershell
$env:ROUTINE_FILE="mi_codigo_original.py"
python dashboard_server.py
```

3. Instala Flask si no lo tienes:

```bash
pip install flask
```

4. Ejecuta:

```bash
python dashboard_server.py
```

5. Abre:

```text
http://localhost:5050
```

## Notas importantes

- El dashboard trabaja externo a la rutina.
- No cambia tiempos, sensores, PLC, UR3, Raspberry, Render, ni lógica de errores.
- Si la rutina falla, el dashboard marca en rojo la última etapa activa antes de que el código cambie a `STOP`.
- El diseño usa dark mode, acentos steel blue, verde para éxito y rojo para falla.
