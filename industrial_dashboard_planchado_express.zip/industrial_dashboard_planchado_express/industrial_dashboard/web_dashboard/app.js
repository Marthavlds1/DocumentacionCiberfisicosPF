const $ = (id) => document.getElementById(id);

let latestState = null;
let pollingTimer = null;

function valueOrDash(value) {
  if (value === null || value === undefined || value === "") return "—";
  return String(value);
}

function hasActiveOrder(data) {
  const orderId = valueOrDash(data.order_id);
  const hasOrderId = orderId !== "—";
  const inactiveStatuses = ["idle", "stopped", "success"];

  return hasOrderId && !inactiveStatuses.includes(data.status);
}

function setConnection(data) {
  const dot = $("connection-dot");
  dot.classList.remove("ok", "error");

  const activeOrder = hasActiveOrder(data);

  if (data.error?.active) {
    dot.classList.add("error");
  } else if (activeOrder) {
    dot.classList.add("ok");
  }

  $("system-status").textContent = activeOrder ? "Hay pedido activo" : "No hay pedido activo";
}

function renderStages(data) {
  const stages = data.stages || [];
  const currentIndex = Number.isInteger(data.current_stage_index) ? data.current_stage_index : -1;
  const errorStage = data.error?.active ? data.error.stage : "";
  const stageList = $("stage-list");

  stageList.innerHTML = "";

  stages.forEach((stage, index) => {
    const item = document.createElement("article");
    item.className = "stage-item";
    item.dataset.number = String(index + 1).padStart(2, "0");

    const isErrorStage = data.error?.active && stage.key === errorStage;
    const isCurrent = !data.error?.active && index === currentIndex;
    const isDone = !data.error?.active && currentIndex > index;

    if (isDone) item.classList.add("done");
    if (isCurrent) item.classList.add("current");
    if (isErrorStage) item.classList.add("error");

    item.innerHTML = `
      <h3>${stage.label}</h3>
      <p>${stage.description}</p>
    `;

    stageList.appendChild(item);
  });

  const denominator = Math.max(stages.length - 1, 1);
  let percent = currentIndex < 0 ? 0 : (currentIndex / denominator) * 100;
  if (data.status === "success") percent = 100;
  if (data.error?.active) {
    const failedIndex = stages.findIndex((stage) => stage.key === errorStage);
    percent = failedIndex < 0 ? percent : (failedIndex / denominator) * 100;
  }

  const progressFill = $("progress-fill");
  progressFill.style.width = `${Math.max(0, Math.min(100, percent))}%`;
  progressFill.classList.toggle("error", Boolean(data.error?.active));

  $("current-stage-chip").textContent = valueOrDash(data.current_stage_label);
}

function renderAlert(data) {
  const alertPanel = $("alert-panel");
  const active = Boolean(data.error?.active);
  alertPanel.classList.toggle("hidden", !active);

  if (!active) return;

  $("alert-stage").textContent = `Detenido en: ${valueOrDash(data.error.stage_label)}`;
  $("alert-message").textContent = valueOrDash(data.error.message);
  $("alert-time").textContent = `Hora: ${valueOrDash(data.error.timestamp)}`;
}

function renderData(data) {
  $("order-id").textContent = valueOrDash(data.order_id);
  $("usuario").textContent = valueOrDash(data.usuario);
  $("cantidad").textContent = valueOrDash(data.cantidad);
  $("tipo-prenda").textContent = valueOrDash(data.tipo_prenda);
  $("confianza-ia").textContent = data.confianza_ia ? `${data.confianza_ia}` : "—";
  $("ultima-foto").textContent = valueOrDash(data.ultima_foto_local);
  $("last-update").textContent = valueOrDash(data.last_update);

  const motor = $("motor");
  motor.textContent = data.motor_encendido ? "ENCENDIDO" : "DETENIDO";
  motor.classList.toggle("on", Boolean(data.motor_encendido));
  motor.classList.toggle("off", !data.motor_encendido);

  const senal = $("senal");
  if (data.senal_000007_activada === null || data.senal_000007_activada === undefined) {
    senal.textContent = "—";
    senal.classList.remove("on", "off");
  } else {
    senal.textContent = data.senal_000007_activada ? "ACTIVA" : "INACTIVA";
    senal.classList.toggle("on", Boolean(data.senal_000007_activada));
    senal.classList.toggle("off", !data.senal_000007_activada);
  }

  const masks = data.sensor_masks || {};
  $("sensores").textContent = `S1:${masks.s1 ? "ON" : "OFF"}  S2:${masks.s2 ? "ON" : "OFF"}  S3:${masks.s3 ? "ON" : "OFF"}`;
}

function renderLogs(data) {
  const logs = data.logs || [];
  if (!logs.length) {
    $("log-output").textContent = "Esperando datos...";
    return;
  }

  $("log-output").textContent = logs.map((entry) => `[${entry.time}] ${entry.line}`).join("\n");
  $("log-output").scrollTop = $("log-output").scrollHeight;
}

function render(data) {
  latestState = data;
  setConnection(data);
  renderAlert(data);
  renderStages(data);
  renderData(data);
  renderLogs(data);
}

async function pollStatus() {
  try {
    const response = await fetch("/api/status", { cache: "no-store" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    render(data);
  } catch (error) {
    const dot = $("connection-dot");
    dot.classList.remove("ok");
    dot.classList.add("error");
    $("system-status").textContent = "Sin conexión al dashboard";
    console.error(error);
  }
}

function startPolling() {
  if (pollingTimer) return;
  pollingTimer = setInterval(pollStatus, 1200);
  pollStatus();
}

function startLiveEvents() {
  if (!window.EventSource) {
    startPolling();
    return;
  }

  const events = new EventSource("/events");

  events.onmessage = (event) => {
    try {
      render(JSON.parse(event.data));
    } catch (error) {
      console.error("Error parsing event", error);
    }
  };

  events.onerror = () => {
    events.close();
    startPolling();
  };
}

async function startRoutine() {
  try {
    const response = await fetch("/api/start", { method: "POST" });
    const payload = await response.json();
    render(payload.state);
  } catch (error) {
    console.error(error);
    alert("No se pudo iniciar la rutina desde el dashboard. Revisa la consola del servidor.");
  }
}

$("start-btn").addEventListener("click", startRoutine);
startLiveEvents();
